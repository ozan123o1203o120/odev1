class Video10 { 
  public static void main(String[] args) {
    //////////////////////////////////////////SWİTCH BLOKLARIYLA ÇALIŞMAK
    char grade = 'A';

    switch(grade) {
      case 'A':
        System.out.println("Not A Mürrrkemmel Bir Not :)");
        break;
      case 'B':
        System.out.println("Not B Güzell :)");
        break;
      case 'C':
        System.out.println("Not C İdare Ediyorsun :)");
        break;
      case 'D':
        System.out.println("Not D Geçtin En Azından :|");
        break;
      case 'F':
        System.out.println("Not F Üzgünüm Kaldın :(");
        break;
      default:
        System.out.println("Geçerli Bir Not Giriniz.");
    }
 }
}