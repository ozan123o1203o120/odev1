class Video6 {
  public static void main(String[] args) {
///////////////////////////////////////////////////////DEĞİKEN KULLANIMI VB.
    
    /////Öğrenci sayımız:
    int ogrencisayi = 10;
    
    /////Verilecek mesaj:
    String mesaj = "Öğrenci sayısı: ";
    
    System.out.println(mesaj + ogrencisayi);
    System.out.println(mesaj + ogrencisayi);
    System.out.println(mesaj + ogrencisayi);
    System.out.println(mesaj + ogrencisayi);
  }
}