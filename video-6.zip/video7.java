class Video7 {
  public static void main(String[] args) {
    //////////////////////////////////////////TEMEL VERİ TİPLERİ

    int sayi = 12;
    sayi = 127312312;

    double sayii = 12.5;
    sayii = -129;

    char karakter = 'A';

    boolean dogruMu = false;
    System.out.println(sayi);
    System.out.println(sayii);
    System.out.println(karakter);
  }
}