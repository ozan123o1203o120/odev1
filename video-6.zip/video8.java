class Video8 { 
  public static void main(String[] args) {
    /////////////////////////////////////////////İF BLOKLARIYLA ÇALIŞMAK
    
    int sayi = 29;
    if(sayi<20) {
      System.out.println("Sayı 20 den küçük");
    }else if(sayi==20) {
      System.out.println("Sayı 20 ye eşit");
    }else if(sayi>20) {
      System.out.println("Sayı 20 den büyük");
    }
  } 
}