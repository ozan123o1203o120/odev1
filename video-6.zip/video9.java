class Video9 { 
  public static void main(String[] args) {
    /////////////////////////////////////////////EN BÜYÜK SAYI BULMACA
    
    int sayi1 = 20;
    int sayi2 = 25;
    int sayi3 = 2;
    int enbuyukkabul = sayi1;
    if(enbuyukkabul<sayi2) {
      enbuyukkabul = sayi2;
}
    if(enbuyukkabul<sayi3) {
      enbuyukkabul = sayi3;
}
    System.out.println("3 sayı arasındaki en büyük sayı: "+enbuyukkabul);
      }
}