class Video11_12_13 { 
  public static void main(String[] args) {
  ///////////////////////////////////////////FOR DÖNGÜSÜ
    for(int i=0; i<=10; i=i+1) {
      System.out.println(i);
    }
    System.out.println("For Döngüsü 0-10 Arası Doğal Sayılar Bitti.");

  ///////////////////////////////////////////WHİLE DÖNGÜSÜ
    int i = 0;
    while(i<=10) {
      System.out.println(i);
      i = i+2;
    }
  System.out.println("While Döngüsü 0-10 Arası Çift Sayılar Bitti.");

  ///////////////////////////////////////////DO-WHİLE DÖNGÜSÜ
    int o=1;
    do{
      System.out.println(o);
      o+=2;
    }while(o<=10);
      System.out.println("Do-While Döngüsü 0-10 Arası Tek Sayılar Bitti.");
 }
}